
import DiscountCode from '@/components/Discount_Code/Discount_Code';
import Layout from '@/components/layout/layout';

export default function AmazingOfferPage() {
  return (
    <Layout>
      {/* <Orders /> */}
      <DiscountCode/>
    </Layout>
  );
}
