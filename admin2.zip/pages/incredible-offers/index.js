
import AmaizingOffer from '@/components/amazingOffer/amazingOffer';
import Layout from '@/components/layout/layout';

export default function AmazingOfferPage() {
  return (
    <Layout>
      {/* <Orders /> */}
      <AmaizingOffer/>
    </Layout>
  );
}
