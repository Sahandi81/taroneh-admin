export const API_URL = process.env.NEXT_PUBLIC_API_URL || 'https://api.taroneh.ir';
export const NEXT_URL =  'http://localhost:5177';
// 'http://localhost:3001' ||