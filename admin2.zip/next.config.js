module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['api.taroneh.ir'],
  },
}
